document.write('\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <br>\
    <div style="text-align: center;">\
        Oops, seems like the this section is under construction! Please come back in <b> 96.45365233 </b> years! Thanks :)\
    </div>\
    ');