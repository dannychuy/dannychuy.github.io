document.write('\
	<!-- Bottom bar -->\
	<a href="https://www.ocf.berkeley.edu">\
    <img src="https://www.ocf.berkeley.edu/hosting-logos/ocfbadge_mini8dark.png" alt="Hosted by the OCF" style="border: 0;" />\
    </a>\
');